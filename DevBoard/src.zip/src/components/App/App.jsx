import './App.css';
import React from 'react';
import Register from '../Register/Register.jsx';

function App() {
  return (
    <div className="app">
      <Register />
    </div>
  );
}

export default App;
